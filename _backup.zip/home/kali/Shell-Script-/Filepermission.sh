#!/bin/bash
file ="/home/kali/Shell-Script-/newuser.sh"

if [-w "$file]; then

echo "$file is writable"

else

echo "$file is not writeable"

fi 
