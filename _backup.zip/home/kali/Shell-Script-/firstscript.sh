
#!/bin/bash

<<note

This is a demo script
note

read -p "Enter the name" name 
echo "My Name is $name"
read -p "Enter the name" name
