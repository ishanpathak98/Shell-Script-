
#!/bin/bash

ps aux --sort=-%mem | head -n 10

